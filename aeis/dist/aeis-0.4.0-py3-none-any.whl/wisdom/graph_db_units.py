# -*- coding: utf-8 -*-
"""graph_db_units.py · 图数据库白箱单元库（第六阶段·目标6 条件图数据库的初级复现）
用户设想：终极目标「条件图数据库」← 初级复现「图数据库」。
与白箱条件路由图同构：知识=节点、条件链=边、遍历=条件链组合、持久化=存储层。
单元：{任务 → 代码模式模板 + 验证样例 + 校准基准}——白箱自举（外部只校准）。
"""
import sys
sys.stdout.reconfigure(encoding='utf-8')

GRAPH_UNITS = {
    "图存储-节点边": {
        "task": "图存储",
        "pattern": (
            "class Graph:\n"
            "    # 图存储：节点 + 有向边（知识=节点，条件链=边）\n"
            "    def __init__(self):\n"
            "        self.nodes = set()\n"
            "        self.edges = {}   # src -> [dst]\n"
            "    def add_node(self, name):\n"
            "        self.nodes.add(name)\n"
            "        self.edges.setdefault(name, [])\n"
            "    def add_edge(self, src, dst):\n"
            "        self.add_node(src)\n"
            "        self.add_node(dst)\n"
            "        if dst not in self.edges[src]:\n"
            "            self.edges[src].append(dst)\n"
            "    def neighbors(self, name):\n"
            "        return list(self.edges.get(name, []))\n"
            "    def remove_edge(self, src, dst):\n"
            "        # 动态图：边删除（增量更新支持）\n"
            "        if src in self.edges and dst in self.edges[src]:\n"
            "            self.edges[src].remove(dst)\n"
            "def graph_ops():\n"
            "    g = Graph()\n"
            "    g.add_edge('气压低', '沸点降')\n"
            "    g.add_edge('沸点降', '煮不熟')\n"
            "    return (sorted(g.nodes), g.neighbors('气压低'))\n"),
        "cases": [("call", (["气压低", "沸点降", "煮不熟"], ["沸点降"]))],
        "params": [],
        "calibration": "对照：条件路由图——知识=节点、条件链=边（气压低→沸点降→煮不熟 条件链）",
    },
    "图遍历-BFS": {
        "task": "图遍历",
        "pattern": (
            "def reachable(graph, start):\n"
            "    # BFS 遍历：从起点出发可达的所有节点（条件链组合——影响传播）\n"
            "    from collections import deque\n"
            "    visited, queue = {start}, deque([start])\n"
            "    while queue:\n"
            "        cur = queue.popleft()\n"
            "        for nxt in graph.neighbors(cur):\n"
            "            if nxt not in visited:\n"
            "                visited.add(nxt)\n"
            "                queue.append(nxt)\n"
            "    return sorted(visited)\n"),
        "cases": [((None, "气压低"), ["气压低", "沸点降", "煮不熟"])],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：条件链组合——从条件出发传播可达的规律（灵枢因果传播同构）",
    },
    "图遍历-路径": {
        "task": "路径查找",
        "pattern": (
            "def has_path(graph, start, end):\n"
            "    # 路径存在性：start 能否到达 end（条件链是否存在）\n"
            "    if start == end:\n"
            "        return True\n"
            "    from collections import deque\n"
            "    visited, queue = {start}, deque([start])\n"
            "    while queue:\n"
            "        cur = queue.popleft()\n"
            "        for nxt in graph.neighbors(cur):\n"
            "            if nxt == end:\n"
            "                return True\n"
            "            if nxt not in visited:\n"
            "                visited.add(nxt)\n"
            "                queue.append(nxt)\n"
            "    return False\n"),
        "cases": [((None, "气压低", "煮不熟"), True),
                  ((None, "煮不熟", "气压低"), False)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：条件链——气压低→沸点降→煮不熟 有路径；反向无（条件链有向）",
    },
    "图持久化-序列化": {
        "task": "图序列化",
        "pattern": (
            "def graph_to_json(graph):\n"
            "    # 图 → JSON 字符串（条件图数据库存储层）\n"
            "    import json\n"
            "    return json.dumps({'nodes': sorted(graph.nodes),\n"
            "                        'edges': {k: v for k, v in sorted(graph.edges.items())}},\n"
            "                       ensure_ascii=False)\n"
            "def graph_from_json(text):\n"
            "    # JSON → 图（存储加载）\n"
            "    import json\n"
            "    data = json.loads(text)\n"
            "    g = Graph()\n"
            "    for n in data['nodes']:\n"
            "        g.add_node(n)\n"
            "    for src, dsts in data['edges'].items():\n"
            "        for d in dsts:\n"
            "            g.add_edge(src, d)\n"
            "    return g\n"),
        "cases": [("call", '{"nodes": [], "edges": {}}')],
        "params": [],
        "calibration": "对照：条件图数据库——图序列化持久化（JSON 存储层）",
    },
    "条件路由图-映射": {
        "task": "条件路由映射",
        "pattern": (
            "def units_to_graph(units):\n"
            "    # 条件单元库 → 条件路由图：知识=节点，conditions=入边（条件→知识）\n"
            "    # units: {知识名: {'conditions': [条件...]}}\n"
            "    g = Graph()\n"
            "    for name, u in units.items():\n"
            "        g.add_node(name)\n"
            "        for c in u.get('conditions', []):\n"
            "            g.add_edge(c, name)   # 条件 → 知识（条件链）\n"
            "    return g\n"),
        "cases": [(({"沸点降": {"conditions": ["气压低"]},
                     "煮不熟": {"conditions": ["沸点降"]}},), ["沸点降"])],
        "params": [],
        "calibration": "对照：条件单元库（{条件→规律}）→ 条件路由图（第4阶段知识图同构）",
    },
    "图持久化-文件": {
        "task": "图文件",
        "pattern": (
            "def save_graph(graph, path):\n"
            "    # 图 → .cgdb 文件（条件图数据库文件）\n"
            "    import json\n"
            "    with open(path, 'w', encoding='utf-8') as f:\n"
            "        json.dump({'nodes': sorted(graph.nodes),\n"
            "                   'edges': {k: v for k, v in sorted(graph.edges.items())}},\n"
            "                  f, ensure_ascii=False)\n"
            "    return path\n"
            "def load_graph(path):\n"
            "    # .cgdb 文件 → 图（条件图数据库加载）\n"
            "    import json\n"
            "    with open(path, 'r', encoding='utf-8') as f:\n"
            "        data = json.load(f)\n"
            "    g = Graph()\n"
            "    for n in data['nodes']:\n"
            "        g.add_node(n)\n"
            "    for src, dsts in data['edges'].items():\n"
            "        for d in dsts:\n"
            "            g.add_edge(src, d)\n"
            "    return g\n"
            "def graph_file_ops():\n"
            "    # 组装：Graph + save + load 往返（条件图数据库持久化）\n"
            "    g = Graph()\n"
            "    g.add_edge('气压低', '沸点降')\n"
            "    path = save_graph(g, 'test.cgdb')\n"
            "    g2 = load_graph(path)\n"
            "    import os\n"
            "    os.remove(path)\n"
            "    return g2.neighbors('气压低')\n"),
        "cases": [("call", ["沸点降"])],
        "params": [],
        "calibration": "对照：条件图数据库——.cgdb 文件持久化（存储层升级：JSON→文件）",
    },
    "图遍历-路径枚举": {
        "task": "路径枚举",
        "pattern": (
            "def all_paths(graph, start, end, max_len=5):\n"
            "    # 枚举 start→end 所有路径（条件链组合——可解释路径）\n"
            "    paths = []\n"
            "    def dfs(cur, path):\n"
            "        if len(path) > max_len:\n"
            "            return\n"
            "        if cur == end:\n"
            "            paths.append(list(path))\n"
            "            return\n"
            "        for nxt in graph.neighbors(cur):\n"
            "            if nxt not in path:\n"
            "                path.append(nxt)\n"
            "                dfs(nxt, path)\n"
            "                path.pop()\n"
            "    dfs(start, [start])\n"
            "    return sorted(paths)\n"),
        "cases": [("call", [["气压低", "沸点降", "煮不熟"],
                            ["气压低", "缺氧", "煮不熟"]])],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：多条件链组合（高压锅在高原=气压低→沸点降 + 气压高→沸点升 两条链的可解释路径）",
    },
    "图遍历-最短路径": {
        "task": "最短路径",
        "pattern": (
            "def shortest_path(graph, start, end):\n"
            "    # 无权图最短路径：BFS 逐层扩散 + 前驱还原（最少条件链跳数）\n"
            "    if start == end:\n"
            "        return [start]\n"
            "    from collections import deque\n"
            "    prev = {start: None}\n"
            "    queue = deque([start])\n"
            "    while queue:\n"
            "        cur = queue.popleft()\n"
            "        for nxt in graph.neighbors(cur):\n"
            "            if nxt not in prev:\n"
            "                prev[nxt] = cur\n"
            "                if nxt == end:\n"
            "                    path = []\n"
            "                    node = nxt\n"
            "                    while node is not None:\n"
            "                        path.append(node)\n"
            "                        node = prev[node]\n"
            "                    return path[::-1]\n"
            "                queue.append(nxt)\n"
            "    return None\n"),
        "cases": [("call", ["气压低", "沸点降", "煮不熟"]),
                  ("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：条件链最短路径——BFS 最少跳数（两链中取最短；反向无路返回 None）",
    },
    "图遍历-加权最短": {
        "task": "加权最短路径",
        "pattern": (
            "def dijkstra(graph, weights, start, end):\n"
            "    # 加权最短路径：Dijkstra 贪心（权重=条件链代价/信任度倒数，小=优）\n"
            "    import heapq\n"
            "    dist = {start: 0}\n"
            "    prev = {start: None}\n"
            "    pq = [(0, start)]\n"
            "    while pq:\n"
            "        d, cur = heapq.heappop(pq)\n"
            "        if d > dist.get(cur, float('inf')):\n"
            "            continue\n"
            "        if cur == end:\n"
            "            break\n"
            "        for nxt in graph.neighbors(cur):\n"
            "            w = weights.get((cur, nxt), 1)\n"
            "            nd = d + w\n"
            "            if nd < dist.get(nxt, float('inf')):\n"
            "                dist[nxt] = nd\n"
            "                prev[nxt] = cur\n"
            "                heapq.heappush(pq, (nd, nxt))\n"
            "    if end not in dist:\n"
            "        return None\n"
            "    path = []\n"
            "    node = end\n"
            "    while node is not None:\n"
            "        path.append(node)\n"
            "        node = prev[node]\n"
            "    return path[::-1], dist[end]\n"),
        "cases": [("call", (["气压低", "缺氧", "煮不熟"], 3))],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：条件链加权最短——Dijkstra 选代价最小链（缺氧路径代价 1+2=3 < 沸点降路径 2+2=4）",
    },
    "条件路由图-查询": {
        "task": "路由查询",
        "pattern": (
            "def route_query(graph, condition):\n"
            "    # 条件路由查询：从条件出发影响传播 → 可达规律（影响面，不含起点）\n"
            "    from collections import deque\n"
            "    visited, queue = set(), deque([condition])\n"
            "    while queue:\n"
            "        cur = queue.popleft()\n"
            "        for nxt in graph.neighbors(cur):\n"
            "            if nxt not in visited:\n"
            "                visited.add(nxt)\n"
            "                queue.append(nxt)\n"
            "    return sorted(visited)\n"),
        "cases": [("call", ["沸点降", "煮不熟", "缺氧"])],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：条件路由查询——条件 → 影响面（规律集合，compose 条件链组合的图查询形态）",
    },
    "条件路由图-对接": {
        "task": "条件单元对接",
        "pattern": (
            "def build_from_condition_units(units):\n"
            "    # compose_engine.CONDITION_UNITS → 条件路由图（知识=单元，conditions=条件入边）\n"
            "    g = Graph()\n"
            "    for name, u in units.items():\n"
            "        g.add_node(name)\n"
            "        for c in u.get('conditions', []):\n"
            "            g.add_edge(c, name)\n"
            "    return g\n"
            "def condition_impact(g, condition):\n"
            "    # 条件 → 影响的知识单元（直接+间接——影响面）\n"
            "    from collections import deque\n"
            "    visited, queue = set(), deque([condition])\n"
            "    while queue:\n"
            "        cur = queue.popleft()\n"
            "        for nxt in g.neighbors(cur):\n"
            "            if nxt not in visited:\n"
            "                visited.add(nxt)\n"
            "                queue.append(nxt)\n"
            "    return sorted(visited)\n"),
        "cases": [(({"沸点-气压": {"conditions": ["气压"]},
                     "密度-浮沉": {"conditions": ["物体", "液体"]}},), 5)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：真实条件单元库（compose_engine 43 单元）→ 条件路由图（条件 → 影响的规律单元）",
    },
    "图查询-模式匹配": {
        "task": "模式匹配",
        "pattern": (
            "def match_pattern(graph, src, rel, dst):\n"
            "    # 图查询语言：MATCH (a)-[r]->(b) 模式 → 匹配的三元组集合\n"
            "    # src/dst 支持 None=任意节点；rel 支持 None=任意边\n"
            "    results = []\n"
            "    for a in sorted(graph.nodes):\n"
            "        if src is not None and a != src:\n"
            "            continue\n"
            "        for b in graph.neighbors(a):\n"
            "            if rel is not None and rel not in (a, b):\n"
            "                continue\n"
            "            if dst is not None and b != dst:\n"
            "                continue\n"
            "            results.append((a, b))\n"
            "    return results\n"),
        "cases": [("call", [('气压低', '沸点降'), ('气压低', '缺氧')])],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图查询语言——MATCH 模式（(a)-[r]->(b)，None=任意，条件路由图三元组查询）",
    },
    "图查询-聚合": {
        "task": "聚合查询",
        "pattern": (
            "def aggregate_by(graph, key_fn):\n"
            "    # 图查询语言：按条件分组聚合（每节点 → 出度计数，GROUP BY 语义）\n"
            "    groups = {}\n"
            "    for node in sorted(graph.nodes):\n"
            "        k = key_fn(node)\n"
            "        groups.setdefault(k, 0)\n"
            "        groups[k] += 1\n"
            "    return groups\n"),
        "cases": [("call", {'气压低': 1, '沸点降': 1, '缺氧': 1, '煮不熟': 1})],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图查询语言——GROUP BY 聚合（按 key_fn 分组计数）",
    },
    "图查询-条件链": {
        "task": "条件链查询",
        "pattern": (
            "def chain_query(graph, condition, max_len=4):\n"
            "    # 图查询语言：从条件出发沿边收集完整链（MATCH (a)-[*]->(b) 路径语义）\n"
            "    chains = []\n"
            "    def walk(cur, path):\n"
            "        if len(path) > max_len:\n"
            "            return\n"
            "        succ = graph.neighbors(cur)\n"
            "        if not succ:\n"
            "            chains.append(list(path))\n"
            "            return\n"
            "        for nxt in succ:\n"
            "            if nxt not in path:\n"
            "                path.append(nxt)\n"
            "                walk(nxt, path)\n"
            "                path.pop()\n"
            "    walk(condition, [condition])\n"
            "    return sorted(chains)\n"),
        "cases": [("call", [['气压低', '沸点降', '煮不熟'],
                            ['气压低', '缺氧', '煮不熟']])],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图查询语言——变长路径 MATCH (a)-[*]->(b)：从条件出发的完整条件链集合",
    },
    "图存储-事务": {
        "task": "图事务",
        "pattern": (
            "def txn_op(state, op, payload=None):\n"
            "    # 图数据库事务：begin 快照 / commit 生效 / rollback 回滚（ACID 原子性）\n"
            "    if op == 'begin':\n"
            "        state['snapshot'] = {k: list(v) if isinstance(v, list) else v\n"
            "                              for k, v in state.get('data', {}).items()}\n"
            "        return 'active'\n"
            "    if op == 'commit':\n"
            "        state['snapshot'] = None\n"
            "        return 'committed'\n"
            "    if op == 'rollback':\n"
            "        if 'snapshot' in state and state['snapshot'] is not None:\n"
            "            state['data'] = state['snapshot']\n"
            "            state['snapshot'] = None\n"
            "        return 'rolled_back'\n"
            "    return 'idle'\n"),
        "cases": [(({'data': {'a': [1]}, 'snapshot': None}, 'begin'), 'active'),
                  (({'data': {'a': [1]}, 'snapshot': {'a': [1]}}, 'commit'),
                   'committed'),
                  (({'data': {'a': [2]}, 'snapshot': {'a': [1]}}, 'rollback'),
                   'rolled_back')],
        "params": [],
        "calibration": "对照：图数据库事务——begin 快照/commit 生效/rollback 回滚（ACID 原子性语义）",
    },
    "图索引-属性索引": {
        "task": "属性索引",
        "pattern": (
            "def index_by_attr(nodes, attr):\n"
            "    # 图数据库索引：按属性值分组 → 快速查找（索引加速语义）\n"
            "    idx = {}\n"
            "    for nid, props in nodes.items():\n"
            "        val = props.get(attr)\n"
            "        if val is not None:\n"
            "            idx.setdefault(val, []).append(nid)\n"
            "    return {k: sorted(v) for k, v in idx.items()}\n"),
        "cases": [(({'a': {'type': '条件'}, 'b': {'type': '规律'}, 'c': {'type': '条件'}},
                    'type'),
                   {'条件': ['a', 'c'], '规律': ['b']}),
                  (({'x': {'t': 1}}, 'none'), {})],
        "params": [],
        "calibration": "对照：图数据库索引——按属性值分组（type 索引：条件→[a,c] 规律→[b]）",
    },
    "图查询-子图匹配": {
        "task": "子图匹配",
        "pattern": (
            "def subgraph_match(graph, pattern):\n"
            "    # 图查询：模式子图匹配（pattern=[(src, dst), ...] 边列表 → 存在性）\n"
            "    # 所有边都在图中存在 → 匹配成功（子图同构简化版）\n"
            "    for s, d in pattern:\n"
            "        if d not in graph.neighbors(s):\n"
            "            return False\n"
            "    return True\n"),
        "cases": [("call", True),
                  ("call", False)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图查询——子图模式匹配（模式边全部存在=匹配；缺边=不匹配）",
    },
    "图算法-PageRank": {
        "task": "PageRank",
        "pattern": (
            "def pagerank(graph, iterations=5, damping=0.85):\n"
            "    # PageRank：权重迭代传播（出链均分，阻尼因子防死端）\n"
            "    nodes = sorted(graph.nodes)\n"
            "    n = len(nodes)\n"
            "    pr = {node: 1.0 / n for node in nodes}\n"
            "    for _ in range(iterations):\n"
            "        new_pr = {node: (1 - damping) / n for node in nodes}\n"
            "        for node in nodes:\n"
            "            out = graph.neighbors(node)\n"
            "            if not out:\n"
            "                continue\n"
            "            share = damping * pr[node] / len(out)\n"
            "            for nxt in out:\n"
            "                new_pr[nxt] += share\n"
            "        pr = new_pr\n"
            "    return pr\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图算法——PageRank（权重迭代传播，入链多者排名高）",
    },
    "图算法-连通分量": {
        "task": "连通分量",
        "pattern": (
            "def connected_components(graph):\n"
            "    # 无向连通分量：BFS 分组（边双向视为连通，互达节点同组）\n"
            "    from collections import deque\n"
            "    # 构建无向邻接（edges 双向化）\n"
            "    adj = {n: set(graph.neighbors(n)) for n in graph.nodes}\n"
            "    for n in list(graph.nodes):\n"
            "        for nxt in graph.neighbors(n):\n"
            "            adj.setdefault(nxt, set()).add(n)\n"
            "    seen = set()\n"
            "    comps = []\n"
            "    for start in sorted(graph.nodes):\n"
            "        if start in seen:\n"
            "            continue\n"
            "        group = set()\n"
            "        queue = deque([start])\n"
            "        seen.add(start)\n"
            "        while queue:\n"
            "            cur = queue.popleft()\n"
            "            group.add(cur)\n"
            "            for nxt in adj.get(cur, set()):\n"
            "                if nxt not in seen:\n"
            "                    seen.add(nxt)\n"
            "                    queue.append(nxt)\n"
            "        comps.append(sorted(group))\n"
            "    return sorted(comps)\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图算法——连通分量（无向互达分组）",
    },
    "图算法-拓扑排序": {
        "task": "拓扑排序",
        "pattern": (
            "def topological_sort(graph):\n"
            "    # 拓扑排序：DAG 依赖顺序（Kahn 算法——入度归零先出）\n"
            "    from collections import deque\n"
            "    indeg = {node: 0 for node in graph.nodes}\n"
            "    for node in graph.nodes:\n"
            "        for nxt in graph.neighbors(node):\n"
            "            indeg[nxt] = indeg.get(nxt, 0) + 1\n"
            "    queue = deque(sorted(n for n, d in indeg.items() if d == 0))\n"
            "    order = []\n"
            "    while queue:\n"
            "        cur = queue.popleft()\n"
            "        order.append(cur)\n"
            "        for nxt in graph.neighbors(cur):\n"
            "            indeg[nxt] -= 1\n"
            "            if indeg[nxt] == 0:\n"
            "                queue.append(nxt)\n"
            "    return order if len(order) == len(graph.nodes) else None\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图算法——拓扑排序（Kahn 入度归零，DAG 依赖顺序；有环返回 None）",
    },
    "图查询-执行计划": {
        "task": "执行计划",
        "pattern": (
            "def query_plan(conditions, stats):\n"
            "    # 查询执行计划：按选择性排序条件（低选择性先执行——查询优化语义）\n"
            "    plan = sorted(conditions, key=lambda c: stats.get(c, 0))\n"
            "    return plan\n"),
        "cases": [((['a', 'b', 'c'], {'a': 10, 'b': 2, 'c': 50}), ['b', 'a', 'c']),
                  ((['x'], {'x': 1}), ['x']),
                  ((['a', 'b'], {}), ['a', 'b'])],
        "params": [],
        "calibration": "对照：图查询优化——执行计划（按选择性升序，低选择性条件先执行）",
    },
    "图存储-批量操作": {
        "task": "批量建图",
        "pattern": (
            "def batch_edges(graph, edges):\n"
            "    # 批量建图：一次添加多条边（批量导入语义）\n"
            "    for src, dst in edges:\n"
            "        graph.add_edge(src, dst)\n"
            "    return len(edges)\n"),
        "cases": [("call", 3)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图数据库批量导入（多条边一次性建图）",
    },
    "图索引-布隆过滤": {
        "task": "布隆过滤",
        "pattern": (
            "def bloom_filter(items, probe):\n"
            "    # 布隆过滤器：多哈希位数组（成员可能判定，误报可接受）\n"
            "    size = 64\n"
            "    bits = [False] * size\n"
            "    def h1(x):\n"
            "        return sum(ord(c) for c in x) % size\n"
            "    def h2(x):\n"
            "        return (len(x) * 7 + sum(ord(c) for c in x)) % size\n"
            "    for it in items:\n"
            "        bits[h1(it)] = bits[h2(it)] = True\n"
            "    return bits[h1(probe)] and bits[h2(probe)]\n"),
        "cases": [((['a', 'b', 'c'], 'b'), True),
                  ((['a', 'b', 'c'], 'z'), False),
                  ((['ab'], 'ab'), True)],
        "params": [],
        "calibration": "对照：图索引——布隆过滤器（多哈希位数组，快速成员判定，可误报）",
    },
    "图算法-节点相似度": {
        "task": "节点相似度",
        "pattern": (
            "def jaccard_similarity(graph, a, b):\n"
            "    # 节点相似度：Jaccard（共同邻居 / 邻居并集）——推荐语义\n"
            "    na = set(graph.neighbors(a))\n"
            "    nb = set(graph.neighbors(b))\n"
            "    if not na and not nb:\n"
            "        return 0.0\n"
            "    return len(na & nb) / len(na | nb)\n"),
        "cases": [("call", 0.0)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图算法——Jaccard 相似度（共同邻居占比，推荐/相似节点语义）",
    },
    "图算法-图同构": {
        "task": "图同构判定",
        "pattern": (
            "def graph_isomorphic(edges_a, edges_b):\n"
            "    # 图同构（简化）：边数+节点度序列 相同 → 可能同构（必要条件）\n"
            "    def deg_seq(edges):\n"
            "        nodes = set()\n"
            "        for s, d in edges:\n"
            "            nodes.add(s)\n"
            "            nodes.add(d)\n"
            "        deg = {n: 0 for n in nodes}\n"
            "        for s, d in edges:\n"
            "            deg[s] += 1\n"
            "            deg[d] += 1\n"
            "        return len(nodes), sorted(deg.values())\n"
            "    return deg_seq(edges_a) == deg_seq(edges_b)\n"),
        "cases": [(([('a', 'b'), ('b', 'c')], [('x', 'y'), ('y', 'z')]), True),
                  (([('a', 'b')], [('x', 'y'), ('y', 'z')]), False)],
        "params": [],
        "calibration": "对照：图算法——同构判定（节点数+度序列必要条件，结构等价检测）",
    },
    "图算法-社区发现": {
        "task": "社区发现",
        "pattern": (
            "def label_propagation(graph, iterations=3):\n"
            "    # 社区发现：标签传播（LPA——节点取邻居多数标签收敛）\n"
            "    labels = {n: n for n in graph.nodes}\n"
            "    for _ in range(iterations):\n"
            "        for n in sorted(graph.nodes):\n"
            "            neigh = graph.neighbors(n)\n"
            "            if not neigh:\n"
            "                continue\n"
            "            from collections import Counter\n"
            "            cnt = Counter(labels[x] for x in neigh)\n"
            "            labels[n] = cnt.most_common(1)[0][0]\n"
            "    return labels\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图算法——标签传播社区发现（LPA，邻居多数标签传播收敛）",
    },
    "图灵枢-导出": {
        "task": "图导出灵枢",
        "pattern": (
            "def graph_to_memories(graph, max_chain=4):\n"
            "    # 条件路由图 → 灵枢记忆条目（每节点=条件链卡，可写入灵枢记忆库）\n"
            "    mems = []\n"
            "    for node in sorted(graph.nodes):\n"
            "        succ = graph.neighbors(node)\n"
            "        if succ:\n"
            "            chain = ' → '.join([node] + succ[:max_chain - 1])\n"
            "            mems.append({'content': '[条件链] ' + chain,\n"
            "                         'tags': ['graph', 'condition-chain', node],\n"
            "                         'importance': 0.7})\n"
            "    return mems\n"),
        "cases": [("call", 1)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图数据库 × 灵枢——条件路由图导出为灵枢记忆条目（条件链卡，可召回重建）",
    },
    "图存储-快照版本": {
        "task": "快照版本",
        "pattern": (
            "def snapshot_ops(repo, op, version=None, state=None):\n"
            "    # 图版本快照：保存/回溯（时间点恢复语义）\n"
            "    if op == 'save':\n"
            "        ver = repo.get('next', 1)\n"
            "        repo['versions'][ver] = dict(state or {})\n"
            "        repo['next'] = ver + 1\n"
            "        return ver\n"
            "    if op == 'restore':\n"
            "        return repo['versions'].get(version)\n"
            "    if op == 'list':\n"
            "        return sorted(repo['versions'].keys())\n"
            "    return None\n"),
        "cases": [(({'versions': {}, 'next': 1}, 'save', None, {'a': 1}), 1),
                  (({'versions': {1: {'a': 1}}, 'next': 2}, 'restore', 1),
                   {'a': 1}),
                  (({'versions': {1: {'a': 1}}, 'next': 2}, 'list'), [1])],
        "params": [],
        "calibration": "对照：图数据库版本管理——快照保存/回溯（时间点恢复）",
    },
    "图查询-时序查询": {
        "task": "时序查询",
        "pattern": (
            "def time_query(history, time):\n"
            "    # 时序图查询：时间点 → 该时刻图状态（快照序列检索）\n"
            "    snaps = sorted(history.keys())\n"
            "    cur = {}\n"
            "    for t in snaps:\n"
            "        if t <= time:\n"
            "            cur = history[t]\n"
            "        else:\n"
            "            break\n"
            "    return cur\n"),
        "cases": [(({1: {'a': 1}, 3: {'a': 2}}, 2), {'a': 1}),
                  (({1: {'a': 1}}, 5), {'a': 1}),
                  (({3: {'a': 2}}, 1), {})],
        "params": [],
        "calibration": "对照：时序图查询——时间点最近快照（快照序列时间回溯）",
    },
    "图算法-增量更新": {
        "task": "增量更新",
        "pattern": (
            "def incr_update(graph, edge, op):\n"
            "    # 动态图增量：边增删（增量维护，不重建全图）\n"
            "    src, dst = edge\n"
            "    if op == 'add':\n"
            "        graph.add_edge(src, dst)\n"
            "        return 'added'\n"
            "    if op == 'remove':\n"
            "        graph.remove_edge(src, dst)\n"
            "        return 'removed'\n"
            "    return None\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：动态图——增量边增删（增量维护语义）",
    },
    "图存储-分区分片": {
        "task": "分区分片",
        "pattern": (
            "def graph_shard(nodes, shards):\n"
            "    # 图分区：节点确定性哈希 → 分片（水平扩展语义）\n"
            "    parts = {i: [] for i in range(shards)}\n"
            "    for n in nodes:\n"
            "        parts[sum(ord(c) for c in n) % shards].append(n)\n"
            "    return {k: sorted(v) for k, v in parts.items()}\n"),
        "cases": [((['a', 'b', 'c', 'd'], 2), {0: ['b', 'd'], 1: ['a', 'c']}),
                  (([], 3), {0: [], 1: [], 2: []})],
        "params": [],
        "calibration": "对照：分布式图——哈希分片（节点分布到分片，水平扩展）",
    },
    "图存储-主从复制": {
        "task": "主从复制",
        "pattern": (
            "def replication(replicas, op, key=None, value=None):\n"
            "    # 主从复制：写主节点 → 同步从节点（读扩展/容错）\n"
            "    if op == 'write':\n"
            "        for r in replicas:\n"
            "            r[key] = value\n"
            "        return len(replicas)\n"
            "    if op == 'read':\n"
            "        return replicas[0].get(key)  # 读主副本\n"
            "    return None\n"),
        "cases": [(([{}, {}], 'write', 'k', 'v'), 2),
                  (([{'k': 'v'}, {'k': 'v'}], 'read', 'k'), 'v'),
                  (([{'k': 'v'}, {'k': 'x'}], 'read', 'k'), 'v')],
        "params": [],
        "calibration": "对照：分布式图——主从复制（写全副本同步，读主副本）",
    },
    "图查询-分布式查询": {
        "task": "分布式查询",
        "pattern": (
            "def dist_query(shards, query_fn):\n"
            "    # 分布式查询：各分片并行查 → 合并结果（MapReduce 语义）\n"
            "    results = []\n"
            "    for shard in shards:\n"
            "        results.extend(query_fn(shard))\n"
            "    return sorted(results)\n"),
        "cases": [(([[1, 3], [2, 4]], lambda s: [x * 2 for x in s]), [2, 4, 6, 8]),
                  (([[], []], lambda s: s), [])],
        "params": [],
        "calibration": "对照：分布式查询——分片并行处理合并（Map 归约语义）",
    },
    "图可视化-力导向布局": {
        "task": "力导向布局",
        "pattern": (
            "def force_layout(nodes, edges, iterations=2):\n"
            "    # 力导向布局：斥力+引力迭代（节点坐标稳定——图可视化）\n"
            "    pos = {n: i * 1.0 for i, n in enumerate(nodes)}  # 初始线性\n"
            "    for _ in range(iterations):\n"
            "        for a in nodes:\n"
            "            for b in nodes:\n"
            "                if a != b and pos[a] < pos[b]:\n"
            "                    pos[a] += 0.1  # 斥力推远\n"
            "                    pos[b] -= 0.1\n"
            "        for a, b in edges:\n"
            "            pos[b] = (pos[a] + pos[b]) / 2  # 引力拉近\n"
            "    return {n: round(pos[n], 2) for n in nodes}\n"),
        "cases": [((['a', 'b'], [('a', 'b')], 1), {'a': 0.1, 'b': 0.5}),
                  ((['x'], [], 1), {'x': 0.0})],
        "params": [],
        "calibration": "对照：图可视化——力导向布局（斥力推离+引力拉近迭代收敛）",
    },
    "图可视化-分层布局": {
        "task": "分层布局",
        "pattern": (
            "def layer_layout(graph):\n"
            "    # 分层布局：按 BFS 深度分层（层次坐标——层级图可视化）\n"
            "    from collections import deque\n"
            "    starts = [n for n in graph.nodes if not any(\n"
            "        n in graph.neighbors(m) for m in graph.nodes)]\n"
            "    if not starts:\n"
            "        starts = [min(graph.nodes)]\n"
            "    layers = {}\n"
            "    for s in starts:\n"
            "        q = deque([(s, 0)])\n"
            "        while q:\n"
            "            n, d = q.popleft()\n"
            "            if n not in layers or d < layers[n]:\n"
            "                layers[n] = d\n"
            "            for nxt in graph.neighbors(n):\n"
            "                if nxt not in layers or d + 1 < layers[nxt]:\n"
            "                    q.append((nxt, d + 1))\n"
            "    return layers\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图可视化——分层布局（BFS 深度分层坐标）",
    },
    "图可视化-邻接矩阵": {
        "task": "邻接矩阵",
        "pattern": (
            "def adjacency_matrix(graph):\n"
            "    # 邻接矩阵：节点 × 节点 0/1（图的结构矩阵表示）\n"
            "    nodes = sorted(graph.nodes)\n"
            "    idx = {n: i for i, n in enumerate(nodes)}\n"
            "    mat = [[0] * len(nodes) for _ in nodes]\n"
            "    for n in nodes:\n"
            "        for nxt in graph.neighbors(n):\n"
            "            mat[idx[n]][idx[nxt]] = 1\n"
            "    return mat\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图可视化——邻接矩阵（0/1 结构矩阵表示）",
    },
    "图存储-备份恢复": {
        "task": "备份恢复",
        "pattern": (
            "def backup_ops(repo, op, data=None):\n"
            "    # 图备份：全量备份/增量合并/恢复（数据安全语义）\n"
            "    if op == 'full':\n"
            "        repo['full'] = dict(data or {})\n"
            "        repo['incr'] = {}\n"
            "        return 'full_backed'\n"
            "    if op == 'incr':\n"
            "        repo['incr'].update(data or {})\n"
            "        return 'incr_backed'\n"
            "    if op == 'restore':\n"
            "        merged = dict(repo.get('full', {}))\n"
            "        merged.update(repo.get('incr', {}))\n"
            "        return merged\n"
            "    return None\n"),
        "cases": [(({'full': None, 'incr': None}, 'full', {'a': 1}), 'full_backed'),
                  (({'full': {'a': 1}, 'incr': {}}, 'incr', {'b': 2}), 'incr_backed'),
                  (({'full': {'a': 1}, 'incr': {'b': 2}}, 'restore'),
                   {'a': 1, 'b': 2})],
        "params": [],
        "calibration": "对照：图备份——全量+增量合并恢复（数据安全）",
    },
    "图存储-一致性检查": {
        "task": "一致性检查",
        "pattern": (
            "def integrity_check(graph):\n"
            "    # 一致性：边两端节点存在 + 无重复边（数据完整性）\n"
            "    errors = []\n"
            "    seen = set()\n"
            "    for src in graph.nodes:\n"
            "        for dst in graph.neighbors(src):\n"
            "            if dst not in graph.nodes:\n"
            "                errors.append(f'悬空边: {src}→{dst}')\n"
            "            if (src, dst) in seen:\n"
            "                errors.append(f'重复边: {src}→{dst}')\n"
            "            seen.add((src, dst))\n"
            "    return errors\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图完整性——一致性检查（悬空边/重复边检测）",
    },
    "图存储-压缩编码": {
        "task": "图压缩",
        "pattern": (
            "def compress_adjacency(graph):\n"
            "    # 图压缩：邻接表 CSR 表示（顶点偏移+邻接数组——紧凑存储）\n"
            "    nodes = sorted(graph.nodes)\n"
            "    offsets, adj = [], []\n"
            "    for n in nodes:\n"
            "        offsets.append(len(adj))\n"
            "        adj.extend(sorted(graph.neighbors(n)))\n"
            "    offsets.append(len(adj))\n"
            "    return {'nodes': nodes, 'offsets': offsets, 'adj': adj}\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图压缩——CSR 邻接表（顶点偏移+邻接数组，紧凑存储）",
    },
    "图监控-指标统计": {
        "task": "图指标",
        "pattern": (
            "def graph_metrics(graph):\n"
            "    # 图指标：节点数/边数/密度（规模与稀疏度）\n"
            "    n = len(graph.nodes)\n"
            "    e = sum(len(graph.neighbors(x)) for x in graph.nodes)\n"
            "    density = (2 * e / (n * (n - 1))) if n > 1 else 0.0\n"
            "    return {'nodes': n, 'edges': e, 'density': round(density, 2)}\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图监控——指标统计（节点/边/密度）",
    },
    "图监控-健康检查": {
        "task": "健康检查",
        "pattern": (
            "def health_check(graph):\n"
            "    # 健康检查：无向连通（正反向边都走）+ 无孤立节点（可用性判定）\n"
            "    if not graph.nodes:\n"
            "        return ('ok', True)\n"
            "    # 无向邻接（正向+反向边）\n"
            "    adj = {n: set(graph.neighbors(n)) for n in graph.nodes}\n"
            "    for n in graph.nodes:\n"
            "        for nxt in graph.neighbors(n):\n"
            "            adj.setdefault(nxt, set()).add(n)\n"
            "    visited = set()\n"
            "    stack = [next(iter(graph.nodes))]\n"
            "    while stack:\n"
            "        cur = stack.pop()\n"
            "        if cur in visited:\n"
            "            continue\n"
            "        visited.add(cur)\n"
            "        stack.extend(adj.get(cur, set()))\n"
            "    if len(visited) != len(graph.nodes):\n"
            "        return ('isolated', False)\n"
            "    return ('ok', True)\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图监控——健康检查（全图连通无孤立节点）",
    },
    "图监控-度分布": {
        "task": "度分布",
        "pattern": (
            "def degree_distribution(graph):\n"
            "    # 度分布：出度直方图（度 → 节点数，结构统计）\n"
            "    hist = {}\n"
            "    for n in graph.nodes:\n"
            "        d = len(graph.neighbors(n))\n"
            "        hist[d] = hist.get(d, 0) + 1\n"
            "    return hist\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图监控——度分布直方图（出度 → 节点数）",
    },
    "图嵌入-节点特征": {
        "task": "节点特征",
        "pattern": (
            "def node_features(graph):\n"
            "    # 节点特征：度/入度/出度（图学习特征向量）\n"
            "    out_deg = {n: len(graph.neighbors(n)) for n in graph.nodes}\n"
            "    in_deg = {n: 0 for n in graph.nodes}\n"
            "    for n in graph.nodes:\n"
            "        for nxt in graph.neighbors(n):\n"
            "            in_deg[nxt] += 1\n"
            "    return {n: {'out': out_deg[n], 'in': in_deg[n]}\n"
            "            for n in sorted(graph.nodes)}\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图嵌入——节点特征（出度/入度向量，图学习输入）",
    },
    "图嵌入-图特征": {
        "task": "图特征",
        "pattern": (
            "def graph_features(graph):\n"
            "    # 图级特征：节点数/边数/连通分量数（图分类输入）\n"
            "    n = len(graph.nodes)\n"
            "    e = sum(len(graph.neighbors(x)) for x in graph.nodes)\n"
            "    return {'nodes': n, 'edges': e, 'density': round(\n"
            "        2 * e / (n * (n - 1)), 2) if n > 1 else 0.0}\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图嵌入——图级特征（节点/边/密度，图分类输入）",
    },
    "图学习-相似推荐": {
        "task": "相似推荐",
        "pattern": (
            "def similar_recommend(graph, node, top=2):\n"
            "    # 相似推荐：共同邻居最多的节点（协同过滤语义）\n"
            "    def common(a, b):\n"
            "        na = set(graph.neighbors(a))\n"
            "        nb = set(graph.neighbors(b))\n"
            "        return len(na & nb)\n"
            "    cands = [x for x in graph.nodes if x != node]\n"
            "    cands.sort(key=lambda x: common(node, x), reverse=True)\n"
            "    return cands[:top]\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图学习——相似推荐（共同邻居最多，协同过滤）",
    },
    "图安全-权限控制": {
        "task": "图权限",
        "pattern": (
            "def graph_acl(acl, user, node, action):\n"
            "    # 图权限：节点级访问控制（用户/节点/动作）\n"
            "    rules = acl.get(node, [])\n"
            "    for r in rules:\n"
            "        if r['user'] == user and r['action'] == action:\n"
            "            return r['allow']\n"
            "    return False\n"),
        "cases": [(({'n1': [{'user': 'u1', 'action': 'read', 'allow': True}]},
                    'u1', 'n1', 'read'), True),
                  (({'n1': []}, 'u1', 'n1', 'read'), False)],
        "params": [],
        "calibration": "对照：图安全——节点级 ACL（用户/节点/动作权限）",
    },
    "图安全-租户隔离": {
        "task": "租户隔离",
        "pattern": (
            "def tenant_scope(graph, tenant):\n"
            "    # 租户隔离：返回租户可见节点（数据隔离语义）\n"
            "    return sorted(n for n in graph.nodes\n"
            "                  if graph.owner.get(n) == tenant)\n"),
        "cases": [("call", None)],
        "params": [],
        "needs_inject": True,
        "calibration": "对照：图安全——租户隔离（节点 owner 过滤，多租户数据隔离）",
    },
    "图安全-加密存储": {
        "task": "加密存储",
        "pattern": (
            "def encrypt_node(value, key):\n"
            "    # 图加密：节点值异或密钥（静态数据加密）\n"
            "    return ''.join(chr(ord(c) ^ key) for c in value)\n"
            "def decrypt_node(code, key):\n"
            "    return ''.join(chr(ord(c) ^ key) for c in code)\n"),
        "cases": [(('秘密', 7), '租寁'),
                  (('数据', 3), '敳捭')],
        "params": [],
        "calibration": "对照：图安全——加密存储（异或加密/解密，静态数据保护）",
    },
    "运维-读写分离": {
        "task": "读写分离",
        "pattern": (
            "def rw_split(master, replicas, op, key=None, value=None, replica_id=0):\n"
            "    # 读写分离：写→主库并同步从库 / 读→从库（负载分散，主从一致）\n"
            "    if op == 'write':\n"
            "        master[key] = value\n"
            "        for r in replicas:\n"
            "            r[key] = value\n"
            "        return 'written'\n"
            "    if op == 'read':\n"
            "        if replicas:\n"
            "            rep = replicas[replica_id % len(replicas)]\n"
            "            return rep.get(key)\n"
            "        return master.get(key)\n"
            "    return None\n"),
        "cases": [(({'a': 1}, [{}, {}], 'write', 'b', 2, 0), 'written'),
                  (({'a': 1}, [{'a': 1}], 'read', 'a', None, 0), 1),
                  (({'a': 1}, [], 'read', 'a', None, 0), 1)],
        "params": [],
        "calibration": "对照：数据库读写分离——主库写+同步从库，从库读（负载分散）",
    },
    "运维-慢查询定位": {
        "task": "慢查询定位",
        "pattern": (
            "def slow_query_scan(plan_times, threshold):\n"
            "    # 慢查询定位：执行计划耗时 > 阈值 → 慢查询列表（耗时降序）\n"
            "    slow = [(op, t) for op, t in plan_times if t > threshold]\n"
            "    slow.sort(key=lambda x: x[1], reverse=True)\n"
            "    return slow\n"),
        "cases": [(([('全表扫描', 2.5), ('索引查找', 0.3)], 1.0),
                   [('全表扫描', 2.5)]),
                  (([('a', 1.0)], 1.0), []),
                  (([], 1.0), [])],
        "params": [],
        "calibration": "对照：数据库慢查询——耗时超阈值定位（降序，等于阈值不算）",
    },
    "运维-在线扩容": {
        "task": "在线扩容",
        "pattern": (
            "def rebalance_keys(keys, old_count, new_count):\n"
            "    # 在线扩容：键按确定性哈希重分配到新片（取模），统计迁移键\n"
            "    # （ord 求和哈希避免 PYTHONHASHSEED 跨进程波动）\n"
            "    moved = 0\n"
            "    for k in keys:\n"
            "        h = sum(ord(c) for c in str(k))\n"
            "        if h % old_count != h % new_count:\n"
            "            moved += 1\n"
            "    return moved, new_count\n"),
        "cases": [((['a', 'b', 'c'], 2, 3), (2, 3)),
                  ((['a'], 2, 2), (0, 2)),
                  (([], 2, 4), (0, 4))],
        "params": [],
        "calibration": "对照：数据库在线扩容——分片重平衡（确定性哈希，迁移键计数）",
    },
    "图算法-最小生成树": {
        "task": "最小生成树",
        "pattern": (
            "def kruskal_mst(edges, n):\n"
            "    # 最小生成树：Kruskal——按权重升序加边，并查集避环（最小连通代价）\n"
            "    parent = list(range(n))\n"
            "    def find(x):\n"
            "        while parent[x] != x:\n"
            "            parent[x] = parent[parent[x]]\n"
            "            x = parent[x]\n"
            "        return x\n"
            "    total, count = 0, 0\n"
            "    for u, v, w in sorted(edges, key=lambda e: e[2]):\n"
            "        ru, rv = find(u), find(v)\n"
            "        if ru != rv:\n"
            "            parent[ru] = rv\n"
            "            total += w\n"
            "            count += 1\n"
            "            if count == n - 1:\n"
            "                break\n"
            "    return total, count\n"),
        "cases": [(([(0, 1, 1), (1, 2, 2), (0, 2, 3)], 3), (3, 2)),
                  (([(0, 1, 5), (1, 2, 3), (0, 2, 1)], 3), (4, 2)),
                  (([], 1), (0, 0))],
        "params": [],
        "calibration": "对照：图算法——Kruskal 最小生成树（升序加边+并查集避环）",
    },
    "图算法-二分图判定": {
        "task": "二分图判定",
        "pattern": (
            "def is_bipartite(adj, n):\n"
            "    # 二分图判定：BFS 染色（相邻异色，颜色冲突即非二分）\n"
            "    color = [-1] * n\n"
            "    for s in range(n):\n"
            "        if color[s] != -1:\n"
            "            continue\n"
            "        color[s] = 0\n"
            "        queue = [s]\n"
            "        while queue:\n"
            "            u = queue.pop(0)\n"
            "            for v in adj.get(u, []):\n"
            "                if color[v] == -1:\n"
            "                    color[v] = 1 - color[u]\n"
            "                    queue.append(v)\n"
            "                elif color[v] == color[u]:\n"
            "                    return False\n"
            "    return True\n"),
        "cases": [(({0: [1], 1: [0, 2], 2: [1]}, 3), True),
                  (({0: [1, 2], 1: [0, 2], 2: [0, 1]}, 3), False),
                  (({}, 1), True)],
        "params": [],
        "calibration": "对照：图算法——二分图判定（BFS 双色染色，相邻异色）",
    },
    "图算法-度中心性": {
        "task": "度中心性",
        "pattern": (
            "def degree_centrality(adj, n):\n"
            "    # 度中心性：节点度数 / (n-1)（归一化——重要度排序依据）\n"
            "    norm = n - 1 if n > 1 else 1\n"
            "    return {k: round(len(v) / norm, 3) for k, v in adj.items()}\n"),
        "cases": [(({0: [1, 2], 1: [0], 2: [0]}, 3),
                   {0: 1.0, 1: 0.5, 2: 0.5}),
                  (({}, 1), {}),
                  (({0: [1]}, 2), {0: 1.0})],
        "params": [],
        "calibration": "对照：图算法——度中心性（度数/(n-1) 归一化重要度）",
    },
    "图查询-正则路径": {
        "task": "正则路径",
        "pattern": (
            "def regex_path_find(adj, start, labels):\n"
            "    # 正则路径查询：按标签序列沿边匹配（存在路径→终点列表）\n"
            "    frontier = [start]\n"
            "    for lab in labels:\n"
            "        nxt = []\n"
            "        for u in frontier:\n"
            "            for v, l in adj.get(u, []):\n"
            "                if l == lab:\n"
            "                    nxt.append(v)\n"
            "        frontier = nxt\n"
            "        if not frontier:\n"
            "            return []\n"
            "    return sorted(set(frontier))\n"),
        "cases": [(({0: [(1, '朋友'), (2, '同事')], 1: [(3, '朋友')]}, 0,
                    ['朋友']), [1]),
                  (({0: [(1, '朋友')], 1: [(2, '朋友')]}, 0,
                    ['朋友', '朋友']), [2]),
                  (({0: [(1, '同事')]}, 0, ['朋友']), [])],
        "params": [],
        "calibration": "对照：图查询——正则路径（标签序列沿边匹配，属性图路径语义）",
    },
    "图查询-查询缓存": {
        "task": "查询缓存",
        "pattern": (
            "def query_cache(cache, op, key=None, result=None, capacity=3):\n"
            "    # 查询缓存：get 命中返回并移末尾 / put 存结果（LRU 淘汰超容量）\n"
            "    if op == 'get':\n"
            "        if key in cache:\n"
            "            val = cache.pop(key)\n"
            "            cache[key] = val\n"
            "            return val\n"
            "        return None\n"
            "    if op == 'put':\n"
            "        if key in cache:\n"
            "            cache.pop(key)\n"
            "        cache[key] = result\n"
            "        while len(cache) > capacity:\n"
            "            cache.pop(next(iter(cache)))\n"
            "        return len(cache)\n"
            "    return None\n"),
        "cases": [(({}, 'put', 'q1', 'r1', 3), 1),
                  (({'q1': 'r1'}, 'get', 'q1', None, 3), 'r1'),
                  (({}, 'get', 'q1', None, 3), None),
                  (({'a': 1, 'b': 2, 'c': 3}, 'put', 'd', 4, 3), 3)],
        "params": [],
        "calibration": "对照：图查询——查询缓存（LRU 淘汰，命中加速重复查询）",
    },
    "图查询-物化视图": {
        "task": "物化视图",
        "pattern": (
            "def materialize_view(base, view_name, view_fn, op, params=None):\n"
            "    # 物化视图：预计算子查询结果（复用加速），refresh 重算\n"
            "    if op == 'query':\n"
            "        v = base.get(view_name)\n"
            "        return v if v is not None else 'missing'\n"
            "    if op == 'refresh':\n"
            "        base[view_name] = view_fn(*(params or []))\n"
            "        return base[view_name]\n"
            "    return None\n"),
        "cases": [(({'热度': [('a', 3)]}, '热度', None, 'query'),
                   [('a', 3)]),
                  (({}, '热度',
                    lambda g: sorted(g, key=lambda x: -x[1]),
                    'refresh', ([('a', 3), ('b', 5)],)),
                   [('b', 5), ('a', 3)]),
                  (({}, '热度', None, 'query'), 'missing')],
        "params": [],
        "calibration": "对照：图查询——物化视图（预计算复用，refresh 重算）",
    },
    "图可视化-环形布局": {
        "task": "环形布局",
        "pattern": (
            "def circular_layout(nodes, cx=0, cy=0, radius=100):\n"
            "    # 环形布局：节点均匀分布圆周（可视化坐标生成）\n"
            "    import math\n"
            "    out = {}\n"
            "    n = len(nodes)\n"
            "    for i, nd in enumerate(nodes):\n"
            "        ang = 2 * math.pi * i / n if n else 0\n"
            "        out[nd] = (round(cx + radius * math.cos(ang), 3),\n"
            "                   round(cy + radius * math.sin(ang), 3))\n"
            "    return out\n"),
        "cases": [((['a'], 0, 0, 10), {'a': (10.0, 0.0)}),
                  (([], 0, 0, 10), {}),
                  ((['a', 'b'], 0, 0, 1), {'a': (1.0, 0.0), 'b': (-1.0, 0.0)})],
        "params": [],
        "calibration": "对照：图可视化——环形布局（圆周均匀分布坐标）",
    },
    "图可视化-视口变换": {
        "task": "视口变换",
        "pattern": (
            "def viewport_transform(x, y, scale, tx, ty):\n"
            "    # 视口变换：缩放平移（zoom/pan——画布坐标映射）\n"
            "    return round(x * scale + tx, 3), round(y * scale + ty, 3)\n"),
        "cases": [((0, 0, 2, 10, 10), (10.0, 10.0)),
                  ((5, 5, 2, 0, 0), (10.0, 10.0)),
                  ((1, 2, 0.5, 1, 1), (1.5, 2.0))],
        "params": [],
        "calibration": "对照：图可视化——视口变换（缩放+平移坐标映射）",
    },
    "图可视化-社区着色": {
        "task": "社区着色",
        "pattern": (
            "def community_color(communities):\n"
            "    # 社区着色：社区分组 → 颜色映射（可视化区分社群）\n"
            "    palette = ['red', 'blue', 'green', 'orange', 'purple']\n"
            "    out = {}\n"
            "    for i, comm in enumerate(communities):\n"
            "        color = palette[i % len(palette)]\n"
            "        for node in comm:\n"
            "            out[node] = color\n"
            "    return out\n"),
        "cases": [(([['a', 'b'], ['c']],), {'a': 'red', 'b': 'red', 'c': 'blue'}),
                  (([],), {}),
                  (([['x']],), {'x': 'red'})],
        "params": [],
        "calibration": "对照：图可视化——社区着色（分组颜色映射）",
    },
    "图存储-邻接表CSR": {
        "task": "邻接表压缩",
        "pattern": (
            "def csr_build(edges, n):\n"
            "    # CSR 邻接表：边列表 → 压缩稀疏行（偏移+邻接数组——紧凑存储）\n"
            "    offsets = [0] * (n + 1)\n"
            "    deg = [0] * n\n"
            "    for u, v in edges:\n"
            "        deg[u] += 1\n"
            "    for i in range(n):\n"
            "        offsets[i + 1] = offsets[i] + deg[i]\n"
            "    adj = [0] * offsets[n]\n"
            "    pos = offsets[:n]\n"
            "    for u, v in edges:\n"
            "        adj[pos[u]] = v\n"
            "        pos[u] += 1\n"
            "    return offsets, adj\n"),
        "cases": [(([(0, 1), (0, 2), (1, 2)], 3), ([0, 2, 3, 3], [1, 2, 2])),
                  (([], 2), ([0, 0, 0], [])),
                  (([(0, 0)], 1), ([0, 1], [0]))],
        "params": [],
        "calibration": "对照：CSR 邻接表——压缩稀疏行（偏移数组+邻接数组，紧凑边存储）",
    },
    "图存储-图合并": {
        "task": "图合并",
        "pattern": (
            "def merge_graphs(g1, g2):\n"
            "    # 图合并：两图邻接合并（节点并集，边并集去重）\n"
            "    merged = {}\n"
            "    for g in (g1, g2):\n"
            "        for u, nbrs in g.items():\n"
            "            merged.setdefault(u, set()).update(nbrs)\n"
            "    return {k: sorted(v) for k, v in merged.items()}\n"),
        "cases": [(({'a': {'b'}}, {'b': {'c'}}), {'a': ['b'], 'b': ['c']}),
                  (({'a': {'b'}}, {'a': {'c'}}), {'a': ['b', 'c']}),
                  (({}, {}), {})],
        "params": [],
        "calibration": "对照：图存储——图合并（节点/边并集，多图整合）",
    },
    "图存储-属性边": {
        "task": "属性边",
        "pattern": (
            "def edge_attr_query(edges, op, u=None, v=None, attr=None):\n"
            "    # 属性边：put 存边属性 / get 查属性 / by_attr 按属性找边\n"
            "    if op == 'put':\n"
            "        edges[(u, v)] = attr\n"
            "        return 'stored'\n"
            "    if op == 'get':\n"
            "        return edges.get((u, v))\n"
            "    if op == 'by_attr':\n"
            "        return sorted(k for k, a in edges.items() if a == attr)\n"
            "    return None\n"),
        "cases": [(({}, 'put', 'a', 'b', '朋友'), 'stored'),
                  (({('a', 'b'): '朋友'}, 'get', 'a', 'b'), '朋友'),
                  (({}, 'get', 'a', 'b'), None),
                  (({('a', 'b'): '朋友', ('c', 'd'): '同事'}, 'by_attr',
                    None, None, '朋友'), [('a', 'b')])],
        "params": [],
        "calibration": "对照：属性图边——带标签/属性边存储与查询",
    },
    "图算法-最大流": {
        "task": "最大流",
        "pattern": (
            "def max_flow(graph, source, sink):\n"
            "    # 最大流：Ford-Fulkerson——BFS 增广路径推送（残留网络）\n"
            "    flow = 0\n"
            "    while True:\n"
            "        parent = {source: None}\n"
            "        queue = [source]\n"
            "        found = False\n"
            "        while queue and not found:\n"
            "            u = queue.pop(0)\n"
            "            for v, cap in graph.get(u, {}).items():\n"
            "                if v not in parent and cap > 0:\n"
            "                    parent[v] = u\n"
            "                    if v == sink:\n"
            "                        found = True\n"
            "                        break\n"
            "                    queue.append(v)\n"
            "        if not found:\n"
            "            break\n"
            "        v = sink\n"
            "        path_flow = float('inf')\n"
            "        while parent[v] is not None:\n"
            "            u = parent[v]\n"
            "            path_flow = min(path_flow, graph[u][v])\n"
            "            v = u\n"
            "        v = sink\n"
            "        while parent[v] is not None:\n"
            "            u = parent[v]\n"
            "            graph[u][v] -= path_flow\n"
            "            graph.setdefault(v, {})[u] = graph.get(v, {}).get(u, 0) + path_flow\n"
            "            v = u\n"
            "        flow += path_flow\n"
            "    return flow\n"),
        "cases": [(({'s': {'a': 3, 'b': 2}, 'a': {'t': 2}, 'b': {'t': 2}},
                    's', 't'), 4),
                  (({'s': {'a': 5}, 'a': {'t': 5}}, 's', 't'), 5),
                  (({'s': {'a': 1}, 'a': {'t': 1}}, 's', 't'), 1)],
        "params": [],
        "calibration": "对照：图算法——最大流（Ford-Fulkerson 增广路径推送）",
    },
    "图算法-欧拉路径": {
        "task": "欧拉路径",
        "pattern": (
            "def euler_path(adj, n):\n"
            "    # 欧拉路径：一笔画判定（0 或 2 个奇度节点——连通图）\n"
            "    deg = {i: len(adj.get(i, [])) for i in range(n)}\n"
            "    odd = sum(1 for d in deg.values() if d % 2)\n"
            "    return odd == 0 or odd == 2\n"),
        "cases": [(({0: [1], 1: [0, 2], 2: [1]}, 3), True),
                  (({0: [1, 2], 1: [0, 2], 2: [0, 1]}, 3), True),
                  (({0: [1, 2], 1: [0], 2: [0]}, 3), True)],
        "params": [],
        "calibration": "对照：图算法——欧拉路径（0/2 个奇度节点一笔画）",
    },
    "图算法-图直径": {
        "task": "图直径",
        "pattern": (
            "def graph_diameter(adj, n):\n"
            "    # 图直径：最长最短路径（全源 BFS 最大距离）\n"
            "    def bfs(s):\n"
            "        dist = {s: 0}\n"
            "        queue = [s]\n"
            "        while queue:\n"
            "            u = queue.pop(0)\n"
            "            for v in adj.get(u, []):\n"
            "                if v not in dist:\n"
            "                    dist[v] = dist[u] + 1\n"
            "                    queue.append(v)\n"
            "        return max(dist.values()) if dist else 0\n"
            "    return max(bfs(i) for i in range(n))\n"),
        "cases": [(({0: [1], 1: [0, 2], 2: [1]}, 3), 2),
                  (({0: [1, 2], 1: [0, 2], 2: [0, 1]}, 3), 1),
                  (({}, 1), 0)],
        "params": [],
        "calibration": "对照：图算法——图直径（最长最短路径）",
    },
    "条件路由图-条件合并": {
        "task": "条件合并",
        "pattern": (
            "def merge_conditions(cond1, cond2):\n"
            "    # 条件合并：两条条件链合并（AND 语义——路由条件叠加，冲突拒绝）\n"
            "    merged = {}\n"
            "    for k in set(cond1) | set(cond2):\n"
            "        if k in cond1 and k in cond2 and cond1[k] != cond2[k]:\n"
            "            return 'conflict'\n"
            "        merged[k] = cond1.get(k, cond2.get(k))\n"
            "    return merged\n"),
        "cases": [(({'温度': '高'}, {'湿度': '大'}), {'温度': '高', '湿度': '大'}),
                  (({'温度': '高'}, {'温度': '高'}), {'温度': '高'}),
                  (({'温度': '高'}, {'温度': '低'}), 'conflict')],
        "params": [],
        "calibration": "对照：条件路由图——条件链合并（AND 叠加，同键异值冲突）",
    },
    "条件路由图-信任传播": {
        "task": "信任传播",
        "pattern": (
            "def trust_propagate(graph, node, trust, decay=0.5):\n"
            "    # 信任传播：信任沿边衰减传播（信任引擎——多跳信任累积）\n"
            "    out = {node: trust}\n"
            "    queue = [(node, trust)]\n"
            "    while queue:\n"
            "        u, t = queue.pop(0)\n"
            "        for v in graph.get(u, []):\n"
            "            nt = round(t * decay, 3)\n"
            "            if v not in out or nt > out[v]:\n"
            "                out[v] = nt\n"
            "                queue.append((v, nt))\n"
            "    return out\n"),
        "cases": [(({'a': ['b'], 'b': ['c']}, 'a', 1.0),
                   {'a': 1.0, 'b': 0.5, 'c': 0.25}),
                  (({'a': []}, 'a', 0.8), {'a': 0.8}),
                  (({}, 'a', 1.0), {'a': 1.0})],
        "params": [],
        "calibration": "对照：条件路由图——信任传播（沿边衰减，多跳信任累积）",
    },
    "条件路由图-信息差收敛": {
        "task": "信息差收敛",
        "pattern": (
            "def info_gap_path(graph, start, end, gap):\n"
            "    # 信息差收敛：沿路径逐节点缩小信息差（路由决策——信息差递减）\n"
            "    path = [start]\n"
            "    cur = start\n"
            "    while cur != end:\n"
            "        nxt = graph.get(cur, [])\n"
            "        if not nxt:\n"
            "            return path, gap, 'stuck'\n"
            "        best = nxt[0]\n"
            "        path.append(best)\n"
            "        cur = best\n"
            "        gap = round(gap * 0.5, 3)\n"
            "        if len(path) > 10:\n"
            "            return path, gap, 'loop'\n"
            "    return path, gap, 'arrived'\n"),
        "cases": [(({'a': ['b'], 'b': ['c']}, 'a', 'c', 1.0),
                   (['a', 'b', 'c'], 0.25, 'arrived')),
                  (({'a': []}, 'a', 'c', 1.0), (['a'], 1.0, 'stuck')),
                  (({'a': ['b']}, 'a', 'a', 1.0), (['a'], 1.0, 'arrived'))],
        "params": [],
        "calibration": "对照：条件路由图——信息差收敛（逐节点减半，路由推进决策）",
    },
    "图存储-增量备份": {
        "task": "增量备份",
        "pattern": (
            "def incremental_backup(backups, op, base=None, changes=None, tag=None):\n"
            "    # 增量备份：full 全量 / incr 增量（记录变更）/ restore 还原\n"
            "    if op == 'full':\n"
            "        backups[tag] = {'type': 'full', 'data': dict(base)}\n"
            "        return tag\n"
            "    if op == 'incr':\n"
            "        backups[tag] = {'type': 'incr', 'base': base,\n"
            "                        'changes': dict(changes)}\n"
            "        return tag\n"
            "    if op == 'restore':\n"
            "        full = backups.get(base)\n"
            "        if full is None:\n"
            "            return None\n"
            "        data = dict(full['data'])\n"
            "        incr = backups.get(tag)\n"
            "        if incr and incr['type'] == 'incr' and incr['base'] == base:\n"
            "            data.update(incr['changes'])\n"
            "        return data\n"
            "    return None\n"),
        "cases": [(({}, 'full', {'a': 1}, None, 'f1'), 'f1'),
                  (({'f1': {'type': 'full', 'data': {'a': 1}}},
                    'incr', 'f1', {'b': 2}, 'i1'), 'i1'),
                  (({'f1': {'type': 'full', 'data': {'a': 1}},
                     'i1': {'type': 'incr', 'base': 'f1',
                            'changes': {'b': 2}}},
                    'restore', 'f1', None, 'i1'), {'a': 1, 'b': 2}),
                  (({}, 'restore', 'f1', None, 'i1'), None)],
        "params": [],
        "calibration": "对照：数据库备份——全量+增量（变更记录，还原叠加）",
    },
    "图存储-一致性快照": {
        "task": "一致性快照",
        "pattern": (
            "def snapshot_isolation(versions, op, key=None, value=None, version=None):\n"
            "    # 一致性快照：版本化读写（读 ≤ 版本最新值——MVCC 快照隔离）\n"
            "    if op == 'write':\n"
            "        versions.setdefault(key, {})[version] = value\n"
            "        return version\n"
            "    if op == 'read':\n"
            "        kv = versions.get(key, {})\n"
            "        if not kv:\n"
            "            return None\n"
            "        avail = [v for v in kv if v <= version]\n"
            "        return kv[max(avail)] if avail else None\n"
            "    return None\n"),
        "cases": [(({}, 'write', 'a', 1, 1), 1),
                  (({'a': {1: 1, 2: 2}}, 'read', 'a', None, 1), 1),
                  (({'a': {1: 1, 2: 2}}, 'read', 'a', None, 2), 2),
                  (({}, 'read', 'a', None, 5), None)],
        "params": [],
        "calibration": "对照：MVCC 快照隔离——版本化读写（读旧版本一致视图）",
    },
    "图分布式-一致性哈希": {
        "task": "一致性哈希",
        "pattern": (
            "def consistent_hash(ring, op, node=None, key=None):\n"
            "    # 一致性哈希：add 节点入环 / locate 键定位（哈希环——最小迁移）\n"
            "    if op == 'add':\n"
            "        h = sum(ord(c) for c in node)\n"
            "        ring[h] = node\n"
            "        return h\n"
            "    if op == 'locate':\n"
            "        if not ring:\n"
            "            return None\n"
            "        kh = sum(ord(c) for c in key)\n"
            "        hs = sorted(ring)\n"
            "        for h in hs:\n"
            "            if h >= kh:\n"
            "                return ring[h]\n"
            "        return ring[hs[0]]\n"
            "    return None\n"),
        "cases": [(({}, 'add', 'n1'), 159),
                  (({159: 'n1', 217: 'n2'}, 'locate', None, 'k1'), 'n1'),
                  (({159: 'n1'}, 'locate', None, 'k9'), 'n1')],
        "params": [],
        "calibration": "对照：分布式哈希环——一致性哈希（键定位，最小迁移）",
    },
    "图查询-邻居查询": {
        "task": "邻居查询",
        "pattern": (
            "def neighbor_query(adj, op, node=None, hops=1):\n"
            "    # 邻居查询：direct 一跳邻居 / multi 多跳邻居（BFS 扩展）\n"
            "    if op == 'direct':\n"
            "        return sorted(adj.get(node, []))\n"
            "    if op == 'multi':\n"
            "        seen = {node}\n"
            "        frontier = [node]\n"
            "        for _ in range(hops):\n"
            "            nxt = []\n"
            "            for u in frontier:\n"
            "                for v in adj.get(u, []):\n"
            "                    if v not in seen:\n"
            "                        seen.add(v)\n"
            "                        nxt.append(v)\n"
            "            frontier = nxt\n"
            "        seen.discard(node)\n"
            "        return sorted(seen)\n"
            "    return None\n"),
        "cases": [(({0: [1, 2]}, 'direct', 0), [1, 2]),
                  (({0: [1], 1: [2]}, 'multi', 0, 2), [1, 2]),
                  (({0: [1]}, 'multi', 0, 1), [1])],
        "params": [],
        "calibration": "对照：图查询——一跳/多跳邻居（BFS 扩展）",
    },
    "图查询-路径过滤": {
        "task": "路径过滤",
        "pattern": (
            "def path_filter(paths, pred):\n"
            "    # 路径过滤：按条件保留路径（长度/终点——路径筛选）\n"
            "    return [p for p in paths if pred(p)]\n"),
        "cases": [(([[0, 1], [0, 2, 1], [0]], lambda p: len(p) >= 2),
                   [[0, 1], [0, 2, 1]]),
                  (([[0, 1]], lambda p: p[-1] == 1), [[0, 1]]),
                  (([], lambda p: True), [])],
        "params": [],
        "calibration": "对照：图查询——路径过滤（按长度/终点条件）",
    },
    "图算法-三角形计数": {
        "task": "三角形计数",
        "pattern": (
            "def triangle_count(adj, n):\n"
            "    # 三角形计数：闭合三元组（聚类检测——社交网络三角）\n"
            "    triangles = 0\n"
            "    for u in range(n):\n"
            "        for v in adj.get(u, []):\n"
            "            if v > u:\n"
            "                for w in adj.get(v, []):\n"
            "                    if w > v and w in adj.get(u, []):\n"
            "                        triangles += 1\n"
            "    return triangles\n"),
        "cases": [(({0: [1, 2], 1: [0, 2], 2: [0, 1]}, 3), 1),
                  (({0: [1], 1: [0, 2], 2: [1]}, 3), 0),
                  (({}, 1), 0)],
        "params": [],
        "calibration": "对照：图算法——三角形计数（闭合三元组，聚类检测）",
    },
    "图查询-导出子图": {
        "task": "导出子图",
        "pattern": (
            "def induced_subgraph(adj, nodes):\n"
            "    # 导出子图：按节点集诱导（节点集 + 内部边）\n"
            "    node_set = set(nodes)\n"
            "    return {u: [v for v in adj.get(u, []) if v in node_set]\n"
            "            for u in node_set}\n"),
        "cases": [(({0: [1, 2], 1: [0], 2: [0]}, [0, 1]), {0: [1], 1: [0]}),
                  (({0: [1], 1: [0]}, [0]), {0: []}),
                  (({}, [0]), {0: []})],
        "params": [],
        "calibration": "对照：图查询——导出子图（节点集诱导，仅内部边）",
    },
    "图时序-时间窗口": {
        "task": "时间窗口",
        "pattern": (
            "def time_window(events, op, start=None, end=None):\n"
            "    # 时间窗口：window 窗口内事件 / count 计数（时序图查询）\n"
            "    if op == 'window':\n"
            "        return [e for e in events if start <= e['t'] <= end]\n"
            "    if op == 'count':\n"
            "        return sum(1 for e in events if start <= e['t'] <= end)\n"
            "    return None\n"),
        "cases": [(([{'t': 1, 'e': 'a'}, {'t': 3, 'e': 'b'}, {'t': 5, 'e': 'c'}],
                    'window', 2, 4), [{'t': 3, 'e': 'b'}]),
                  (([{'t': 1}, {'t': 3}], 'count', 1, 3), 2),
                  (([], 'window', 0, 10), [])],
        "params": [],
        "calibration": "对照：时序图查询——时间窗口内事件（滑窗过滤）",
    },
    "图动态-边活跃度": {
        "task": "边活跃度",
        "pattern": (
            "def edge_activity(edges, op, edge=None, now=None):\n"
            "    # 边活跃度：touch 更新活跃时间 / active 活跃判定（时间窗内）\n"
            "    if op == 'touch':\n"
            "        edges[edge] = now\n"
            "        return now\n"
            "    if op == 'active':\n"
            "        last = edges.get(edge)\n"
            "        return last is not None and (now - last) <= 10\n"
            "    return None\n"),
        "cases": [(({}, 'touch', ('a', 'b'), 5), 5),
                  (({('a', 'b'): 5}, 'active', ('a', 'b'), 12), True),
                  (({('a', 'b'): 5}, 'active', ('a', 'b'), 20), False),
                  (({}, 'active', ('a', 'b'), 10), False)],
        "params": [],
        "calibration": "对照：动态图——边活跃度（时间窗内活跃判定）",
    },
    "图查询-模式路径": {
        "task": "模式路径",
        "pattern": (
            "def pattern_path(adj, start, min_deg, steps):\n"
            "    # 模式路径：按节点度数模式匹配（每步需出度 ≥ min_deg）\n"
            "    path = [start]\n"
            "    cur = start\n"
            "    for _ in range(steps):\n"
            "        nbrs = adj.get(cur, [])\n"
            "        if len(nbrs) < min_deg:\n"
            "            return path, 'stuck'\n"
            "        nxt = nbrs[0]\n"
            "        path.append(nxt)\n"
            "        cur = nxt\n"
            "    return path, 'matched'\n"),
        "cases": [(({0: [1, 2], 1: [2, 3], 2: [3]}, 0, 2, 1), ([0, 1], 'matched')),
                  (({0: [1], 1: []}, 0, 2, 1), ([0], 'stuck')),
                  (({0: [1, 2], 1: [3, 4], 2: [5]}, 0, 2, 2),
                   ([0, 1, 3], 'matched'))],
        "params": [],
        "calibration": "对照：图查询——模式路径（节点度数模式匹配）",
    },
    "图可视化-节点标签": {
        "task": "节点标签",
        "pattern": (
            "def node_labels(positions, labels):\n"
            "    # 节点标签：为节点附标签（可视化标注，缺省 ?）\n"
            "    return {node: labels.get(node, '?') for node in positions}\n"),
        "cases": [((['a', 'b'], {'a': '甲'}), {'a': '甲', 'b': '?'}),
                  (([], {}), {}),
                  ((['a'], {'a': 'x'}), {'a': 'x'})],
        "params": [],
        "calibration": "对照：图可视化——节点标签标注（缺省占位）",
    },
    "图查询-模糊匹配": {
        "task": "模糊匹配",
        "pattern": (
            "def fuzzy_match(query, nodes, names, threshold=0):\n"
            "    # 模糊匹配：查询与节点名公共字符数 ≥ 阈值（近似名称匹配）\n"
            "    out = []\n"
            "    for n in nodes:\n"
            "        common = len(set(query) & set(names.get(n, '')))\n"
            "        if common >= threshold:\n"
            "            out.append((n, common))\n"
            "    return out\n"),
        "cases": [(('水', ['n1', 'n2'], {'n1': '水壶', 'n2': '电灯'}, 1),
                   [('n1', 1)]),
                  (('火', ['n1'], {'n1': '水壶'}, 1), []),
                  (('水', [], {}, 1), [])],
        "params": [],
        "calibration": "对照：图查询——模糊匹配（公共字符数近似名称）",
    },
    "条件路由图-条件回溯": {
        "task": "条件回溯",
        "pattern": (
            "def condition_backtrack(prev, end, conditions):\n"
            "    # 条件回溯：沿前驱链收集条件（反向推导路径条件）\n"
            "    conds = []\n"
            "    cur = end\n"
            "    seen = set()\n"
            "    while cur is not None and cur not in seen:\n"
            "        seen.add(cur)\n"
            "        if cur in conditions:\n"
            "            conds.append(conditions[cur])\n"
            "        cur = prev.get(cur)\n"
            "    return conds\n"),
        "cases": [(({'c': 'b', 'b': 'a'}, 'c', {'a': '高温', 'c': '缺氧'}),
                   ['缺氧', '高温']),
                  (({}, 'a', {'a': 'x'}), ['x']),
                  (({'b': 'a'}, 'b', {}), [])],
        "params": [],
        "calibration": "对照：条件路由图——条件回溯（反向推导路径条件）",
    },
    "条件路由图-信任聚合": {
        "task": "信任聚合",
        "pattern": (
            "def trust_aggregate(paths, op, source=None, target=None, val=None):\n"
            "    # 信任聚合：多路径信任合并（max 最大 / avg 平均——信任路由决策）\n"
            "    if op == 'record':\n"
            "        paths.setdefault((source, target), []).append(val)\n"
            "        return paths[(source, target)]\n"
            "    if op == 'max':\n"
            "        return max(paths.get((source, target), [0]))\n"
            "    if op == 'avg':\n"
            "        vals = paths.get((source, target), [0])\n"
            "        return sum(vals) / len(vals)\n"
            "    return None\n"),
        "cases": [(({}, 'record', 'a', 'c', 0.8), [0.8]),
                  (({('a', 'c'): [0.5, 0.8]}, 'max', 'a', 'c'), 0.8),
                  (({('a', 'c'): [0.5, 0.8]}, 'avg', 'a', 'c'), 0.65),
                  (({}, 'max', 'a', 'c'), 0)],
        "params": [],
        "calibration": "对照：条件路由图——信任聚合（多路径合并取最大/平均）",
    },
    "图安全-审计日志": {
        "task": "审计记录",
        "pattern": (
            "def audit_log(log, op, user=None, action=None, obj=None):\n"
            "    # 审计日志：record 记录操作 / filter 按用户过滤 / count 计数（安全审计）\n"
            "    if op == 'record':\n"
            "        log.append({'user': user, 'action': action, 'obj': obj})\n"
            "        return len(log)\n"
            "    if op == 'filter':\n"
            "        return [e for e in log if e['user'] == user]\n"
            "    if op == 'count':\n"
            "        return len(log)\n"
            "    return None\n"),
        "cases": [(([], 'record', 'u1', '读', '节点a'), 1),
                  (([{'user': 'u1', 'action': '读', 'obj': '节点a'}],
                    'count'), 1),
                  (([{'user': 'u1', 'action': '读', 'obj': 'a'},
                     {'user': 'u2', 'action': '写', 'obj': 'b'}],
                    'filter', 'u2'),
                   [{'user': 'u2', 'action': '写', 'obj': 'b'}])],
        "params": [],
        "calibration": "对照：图安全——审计日志（操作记录/用户过滤）",
    },
}


def route_graph_unit(question):
    """任务识别（问题 → 图数据库单元）"""
    best, best_len = None, 0
    for uid, u in GRAPH_UNITS.items():
        for kw in (u["task"], uid):
            if kw in question and len(kw) > best_len:
                best, best_len = uid, len(kw)
    return best


if __name__ == "__main__":
    print("=== 图数据库白箱单元库（目标6 · 条件图数据库初级复现）===\n")
    for uid, u in GRAPH_UNITS.items():
        print(f"[{uid}] 任务={u['task']} 样例数={len(u['cases'])}")
        print(f"    校准: {u['calibration']}")
    print(f"\n=== 判定 ===\n图数据库单元库: "
          f"{'✔ 5 单元就绪（存储/遍历/路径/持久化/条件路由映射）' if len(GRAPH_UNITS) >= 4 else '✘'}")
